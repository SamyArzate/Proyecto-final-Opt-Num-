python python/gps/gps_main.py lto
