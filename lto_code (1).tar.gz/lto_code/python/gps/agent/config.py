""" Default configuration and hyperparameters for agent objects. """
import numpy as np

# Agent
AGENT = {
    'substeps': 1,
}
